mv open_pdks/*(DN) .
